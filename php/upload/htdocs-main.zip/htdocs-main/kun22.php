<?php
foreach ($_SERVER as $k => $v) {
    echo "{$k}=>{$v}<br/>";
}

?>