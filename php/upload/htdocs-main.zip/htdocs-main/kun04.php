<?php
    $var1 =123;
    $var1 =true;
    $var1 ='kun';
    $var1 =12.3;
    echo gettype($var1);

?>