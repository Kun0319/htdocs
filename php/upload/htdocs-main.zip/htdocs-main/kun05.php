<?php
$var1 = 10;
$var2 = 3;
$var3 = (int) ($var1 / $var2);
$var4 = $var1 % $var2;
echo "{$var1} / {$var2} = {$var3}......{$var4}<br>";
$weight = 80;
echo "{$weight}kg";
?>