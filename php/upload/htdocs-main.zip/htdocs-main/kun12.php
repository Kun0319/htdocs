<?php
$a = 100;
switch ($a) {
    case 1;
        echo 'A';
        break;
    case 10;
        echo 'B';
        break;
    case 100;
        echo 'C';
        break;
    default:
        echo 'X';
        break;
}
echo ' <hr>';
?>