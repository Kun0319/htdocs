<?php
    echo "Hello,World1 <br />\n";
    echo 'Hello,World2 \n';
    echo 'Hello,World3\n';
?>