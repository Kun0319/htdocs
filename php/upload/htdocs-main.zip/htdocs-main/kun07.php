<?php
$x = $_GET['x'];
$y = $_GET['y'];
$v = $x + $y;
echo "{$x}+{$y}={$v}"
?>