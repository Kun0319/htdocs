<h1> Kun big Company</h1>
<hr />
kun: <img src="kun24.php?rate=76" alt=""><br>
Tony: <img src="kun24.php?rate=25" alt=""><br>
Perter: <img src="kun24.php?rate=63" alt=""><br>
Amy: <img src="kun24.php?rate=55" alt=""><br>