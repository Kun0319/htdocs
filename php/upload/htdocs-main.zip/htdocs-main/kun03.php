<?php
// 變數
$var1 = 123;
$true = 123;
echo $true;
?>